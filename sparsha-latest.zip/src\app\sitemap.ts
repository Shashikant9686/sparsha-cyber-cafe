import { MetadataRoute } from 'next';
import { createClient } from '@/lib/supabase/server';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://sparsha-cyber-cafe.vercel.app';
  const supabase = await createClient();

  const { data: services } = await supabase
    .from('services')
    .select('slug, updated_at')
    .eq('status', 'active');

  const serviceRoutes: MetadataRoute.Sitemap = (services || []).map((service) => ({
    url: `${baseUrl}/services/${service.slug}`,
    lastModified: service.updated_at ? new Date(service.updated_at) : new Date(),
    changeFrequency: 'weekly',
    priority: 0.8,
  }));

  const staticRoutes: MetadataRoute.Sitemap = [
    {
      url: baseUrl,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 1.0,
    },
    {
      url: `${baseUrl}/services`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.9,
    },
    {
      url: `${baseUrl}/counselling`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.9,
    },
    {
      url: `${baseUrl}/contact`,
      lastModified: new Date(),
      changeFrequency: 'monthly',
      priority: 0.7,
    },
  ];

  const { data: updates } = await supabase
    .from('announcements')
    .select('slug, updated_at')
    .eq('status', 'active');

  const updateRoutes: MetadataRoute.Sitemap = (updates || []).map((update) => ({
    url: `${baseUrl}/updates/${update.slug}`,
    lastModified: update.updated_at ? new Date(update.updated_at) : new Date(),
    changeFrequency: 'weekly',
    priority: 0.7,
  }));

  return [
    ...staticRoutes,
    ...serviceRoutes,
    { url: `${baseUrl}/updates`, lastModified: new Date(), changeFrequency: 'daily', priority: 0.85 },
    ...updateRoutes,
  ];
}